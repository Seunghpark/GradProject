# LolAi.gg corrected submission materials

Student: 박승현 (2019310220), 소프트웨어학과 / 소프트웨어융합대학.
Adviser: 한환수. Track: 개인 작품.

The department confirmed the correct student number on November 2, 2026.
This local correction contains the same 47-page report with only its cover
student number corrected, the official one-slide presentation with the
correct number and filename, and the previously checked application source.
Report content, model parameters and measured results have not changed.

- Report/LolAi_FinalReport_v07.pdf
- Presentation/소프트웨어학과_박승현(2019310220).pptx
- GradProject/: application source, tests, model artifacts and technical docs
- Administrative/: an N/A notice for the software-project track, not evidence
  of a conference presentation or an official waiver

The checked PDF is the report deliverable. An editable Word copy is not
included in this correction package because its renderer was unavailable.
API keys, private records, installed dependencies and internal prompts are
excluded. The model's limitations and AI-assistance disclosures are retained.

For execution, open GradProject and follow README.md. The demo supports
sample data. Genuine lookups need a valid server-only Riot key.

This packaging operation has not sent an email, changed the school portal,
received adviser approval, or updated GitHub. Existing submitted files remain
separate until the department accepts replacement copies.
